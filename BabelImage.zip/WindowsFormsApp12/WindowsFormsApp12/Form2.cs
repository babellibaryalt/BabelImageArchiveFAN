﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp12
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        int rows = 0;
        int columns = 0;

        Random rnd = new Random();

        private void Form2_Load(object sender, EventArgs e)
        {
            int startingrows = (int)Form1.instance.rowcontrol.Value;
            int startingcols = (int)Form1.instance.columncontrol.Value;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int startingrows = (int)Form1.instance.rowcontrol.Value;
            int startingcols = (int)Form1.instance.columncontrol.Value;
            if (startingcols == 0)
            {
                if (startingcols == 0)
                {

                } else
                {
                    timer2.Start();
                }
            }
            else
            {
                timer2.Start();
            }

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int startingrows = (int)Form1.instance.rowcontrol.Value;
            int startingcols = (int)Form1.instance.columncontrol.Value;
            int sizex = (int)Form1.instance.sizexx.Value;
            int sizey = (int)Form1.instance.sizeyy.Value;
            this.Size = new Size(sizex * startingrows, sizey * startingcols);
            if (rows != startingrows)
            {

                Panel colorpanel = new Panel();
                ///colorpanel.BackColor = Color.FromArgb(rnd.Next(0, 255), rnd.Next(0, 255), rnd.Next(0, 255));
                colorpanel.BackColor = Color.FromArgb(0, rnd.Next(0,255), rnd.Next(0, 255));
                colorpanel.Location = new Point(rows * sizex, columns * sizey);
                colorpanel.Size = new Size(sizex, sizey);
                this.Controls.Add(colorpanel);
                rows = rows + 1;
            }
            else
            {
                if (columns != startingcols - 1)
                {
                    columns = columns + 1;
                    rows = 0;
                }
                else
                {
                }
            }
            if (rows != startingrows)
            {
                if (columns == startingcols - 1)
                {
                    timer2.Stop();
                }
            }
        }

        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            this.Location = new Point(Cursor.Position.X,Cursor.Position.Y);
        }
    }
}
