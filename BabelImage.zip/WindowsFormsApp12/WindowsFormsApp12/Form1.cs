﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp12
{
    public partial class Form1 : Form
    {
        public static Form1 instance;
        public NumericUpDown rowcontrol;
        public NumericUpDown columncontrol;
        public NumericUpDown sizexx;
        public NumericUpDown sizeyy;
        public Form1()
        {
            InitializeComponent();
            instance = this;
            rowcontrol = numericUpDown1;
            columncontrol = numericUpDown2;
            sizexx = numericUpDown3;
            sizeyy = numericUpDown4;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        public int startingrows = 0;
        public int startingcols = 0;  
        Random rnd = new Random();
        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();
            startingrows = (int)numericUpDown1.Value;
            startingcols = (int)numericUpDown2.Value;

        }
        private bool mousedown = false;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mousedown = true;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedown)
            {
                int mousex = MousePosition.X - this.Width;
                int mousey = MousePosition.Y - this.Height;
                this.SetDesktopLocation(mousex, mousey);
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mousedown = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            int time = (int)numericUpDown2.Value * (int)numericUpDown1.Value;
            label5.Text = "Estimated Time:" + time.ToString() + "MS";
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int time = (int)numericUpDown2.Value * (int)numericUpDown1.Value;
            label5.Text = "Estimated Time:" + time.ToString() + "MS";
        }
    }
}
